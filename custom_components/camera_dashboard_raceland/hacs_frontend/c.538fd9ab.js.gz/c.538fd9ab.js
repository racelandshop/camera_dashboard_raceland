import{_ as e,d as a,g as t,t as i,x as o,f as s,q as c}from"./main-b570e60a.js";import"./c.9e58f139.js";import{al as n,am as r,an as l,ao as d,aq as m}from"./c.5a5021e9.js";import{b as h}from"./c.08872315.js";import"./c.f9bdd698.js";import"./c.2aff7a3c.js";import"./c.81a9389e.js";import"./c.a5b80b3f.js";import"./c.3df9613c.js";import"./c.a6c70980.js";const u=n(h,r({title:l(d()),content:d()})),f=[{name:"title",selector:{text:{}}},{name:"content",required:!0,selector:{text:{multiline:!0}}}];let p=e([c("hui-markdown-card-editor")],(function(e,a){return{F:class extends a{constructor(...a){super(...a),e(this)}},d:[{kind:"field",decorators:[t({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[i()],key:"_config",value:void 0},{kind:"method",key:"setConfig",value:function(e){m(e,u),this._config=e}},{kind:"method",key:"render",value:function(){return this.hass&&this._config?o`
      <ha-form
        .hass=${this.hass}
        .data=${this._config}
        .schema=${f}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `:o``}},{kind:"method",key:"_valueChanged",value:function(e){s(this,"config-changed",{config:e.detail.value})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.lovelace.editor.card.generic.${e.name}`)||this.hass.localize(`ui.panel.lovelace.editor.card.markdown.${e.name}`)}}]}}),a);export{p as HuiMarkdownCardEditor};

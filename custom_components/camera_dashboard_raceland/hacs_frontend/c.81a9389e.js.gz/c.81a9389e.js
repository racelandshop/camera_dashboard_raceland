import{_ as r,o as s,q as a}from"./main-b570e60a.js";import{C as o,s as c}from"./c.a5b80b3f.js";r([a("ha-checkbox")],(function(r,a){return{F:class extends a{constructor(...s){super(...s),r(this)}},d:[{kind:"field",static:!0,key:"styles",value:()=>[c,s`
      :host {
        --mdc-radio-unchecked-color: var(--primary-text-color);
        --mdc-theme-secondary: var(--primary-color);
      }
    `]}]}}),o);

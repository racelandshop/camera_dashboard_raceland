import{r,s as t}from"./c.655d6539.js";function e(e){return r(1,arguments),function(e,n){r(2,arguments);var i=t(e),o=t(n);return i.getTime()===o.getTime()}(e,Date.now())}export{e as i};
